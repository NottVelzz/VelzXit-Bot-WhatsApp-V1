const express=require('express');
const http=require('http');
const {Server}=require('socket.io');

const app=express();
const server=http.createServer(app);
const io=new Server(server);

let botStatus='offline';

app.use(express.json());
app.use(express.static('public'));

app.get('/api/status',(req,res)=>{
  res.json({status:botStatus});
});

app.post('/api/toggle',(req,res)=>{
  botStatus = botStatus === 'online' ? 'offline' : 'online';
  io.emit('status', botStatus);
  res.json({status:botStatus});
});

io.on('connection',()=>{});

server.listen(3000,()=>{
  console.log('Dashboard: http://localhost:3000');
});
